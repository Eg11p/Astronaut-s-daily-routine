var Astronaut,bath,brush,drink,eat,gym,move,sleep;
var back,iss;

function preload() {
  bath = loadAnimation("bath1.png","bath2.png");
  brush = loadAnimation("brush.png");
  drink = loadAnimation("drink1.png","drink2.png");
  eat = loadAnimation("eat1.png","eat2.png");
  gym = loadAnimation("gym1.png","gym2.png","gym11.png","gym12.png");
  move = loadAnimation("move.png","move1.png");
  iss = loadImage("iss.png");
  sleep = loadAnimation("sleep.png");
}

function setup() {
  createCanvas(800,400);
  
  back = createSprite(400,200),
  back.addImage(iss);
  back.scale = 0.2;
  Astronaut = createSprite(300,230);
  Astronaut.addAnimation("sleeping",sleep);
  Astronaut.scale = 0.1;
}

function draw() {
  background(255,255,255); 
  
  if(keyDown("UP_ARROW")){
    Astronaut.addAnimation("excercise",gym);
    Astronaut.changeAnimation("excercise");
    Astronaut.y = 300;
    Astronaut.velocityX = 0;
    Astronaut.velocityY = 0;
  }

  if(keyDown("LEFT_ARROW")){
    Astronaut.addAnimation("cleaning",bath);
    Astronaut.changeAnimation("cleaning");
    Astronaut.y = 200;
    Astronaut.velocityX = 0;
    Astronaut.velocityY = 0;
  }

  if(keyDown("RIGHT_ARROW")){
    Astronaut.addAnimation("eating",eat);
    Astronaut.changeAnimation("eating");
    Astronaut.y = 250;
    Astronaut.velocityX = 0;
    Astronaut.velocityY = 0;
  }

  if(keyDown("DOWN_ARROW")){
    Astronaut.addAnimation("drinking",drink);
    Astronaut.changeAnimation("drinking");
    Astronaut.y = 250;
    Astronaut.velocityX = 0;
    Astronaut.velocityY = 0;
  }
  
  if(keyDown("M")){
    Astronaut.addAnimation("moving",move);
    Astronaut.changeAnimation("moving");
    Astronaut.y = 200;
    Astronaut.velocityX = 0;
    Astronaut.velocityY = 0;
    move.depth = iss.depth + 1;
  }

  if(keyDown("B")){
    Astronaut.addAnimation("brushing",brush);
    Astronaut.changeAnimation("brushing");
    Astronaut.y = 250;
    Astronaut.velocityX = 0;
    Astronaut.velocityY = 0;
  }

  drawSprites();
}